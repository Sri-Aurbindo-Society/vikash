export default {
	Username: "required",
	Name: "required",
	SchoolID: "required",
	StateID: "required",
	BoardID: "required",
	GradeID: "required",
	SubjectID: "required",
	UdiseCode: "required",
};
