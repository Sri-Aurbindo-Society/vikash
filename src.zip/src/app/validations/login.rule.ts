export default {
  Name: "required",
  Username: "required",
};
