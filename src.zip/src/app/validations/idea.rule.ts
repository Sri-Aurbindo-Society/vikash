export default {
  Title: "required",
  Description: "required",
  Link: "required",
};
