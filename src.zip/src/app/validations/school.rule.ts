export default {
  SchoolName: "required",
  UDiseCode: "required",
  SchoolTypeID: "required",
  CountryID: "required",
  StateID: "required",
  DistrictID: "required",
  BlockID: "required",
  ClusterID: "",
  VillageID: "",
  Address: "required",
};
