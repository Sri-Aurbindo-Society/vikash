export default {
  userName: "required",
  password: "required|min:6|max:20",
};
