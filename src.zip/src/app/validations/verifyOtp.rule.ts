export default {
  username: "required",
  otp: "required",
};
