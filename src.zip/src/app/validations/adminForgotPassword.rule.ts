export default {
  Email: "required|email",
};
