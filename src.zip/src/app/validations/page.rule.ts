export default {
  PageName: "required",
  PageType: "required",
  Description: "required",
  CreateBy: "required",
};
