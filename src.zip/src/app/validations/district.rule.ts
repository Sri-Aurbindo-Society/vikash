export default {
  StateID: "required",
  DistrictName: "required",
  DistrictCode: "required",
  NativeLanguageName: "",
};
