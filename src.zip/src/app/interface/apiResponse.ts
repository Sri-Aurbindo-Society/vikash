export interface ApiResponse {
  Status: string;
  Error: boolean;
  ErrorCode: string;
  Message: string;
  Result: any;
}
