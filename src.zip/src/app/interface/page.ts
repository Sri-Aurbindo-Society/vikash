export interface Page {
  ID?: string;
  PageName: string;
  PageType: string;
  Description: string;
  CreateBy: string;
}
