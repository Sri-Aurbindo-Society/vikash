export interface Admin {
  UserName: string;
  Name: string;
  Email: string;
  Password: string;
  AdminRoleID?: string;
  Mobile?: string;
  ProfilePic?: string;
  Status?: string;
  CreateBy: string;
}
