export interface District {
  ID?: string;
  StateID: string;
  DistrictName: string;
  DistrictCode: string;
  NativeLanguageName: string;
}
