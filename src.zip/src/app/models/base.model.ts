export abstract class BaseModel {
  protected _createBy: string = null;

  constructor() {}
}
